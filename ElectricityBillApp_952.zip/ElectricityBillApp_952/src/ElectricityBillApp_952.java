import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

/**
 * ElectricityBillApp_952
 * Swing GUI + MySQL (JDBC) for storing & retrieving electricity bills.
 *
 * Change DB constants below if your DB credentials / host are different.
 */
public class ElectricityBillApp_952 extends JFrame {
    // ---------- DB connection settings (edit if needed) ----------
    private static final String DB_URL_952 = "jdbc:mysql://localhost:3306/college_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone";
    private static final String DB_USER_952 = "root";
    private static final String DB_PASS_952 = "leam0312";

    // ---------- Swing components ----------
    private JTextField idField_952, nameField_952, unitsField_952;
    private JButton calcSaveBtn_952, clearBtn_952;

    private JTextField searchNameField_952;
    private JButton searchBtn_952;

    // ---------- JDBC connection ----------
    private Connection conn_952;

    public ElectricityBillApp_952() {
        super("Electricity Bill Manager (_952)");
        initDB_952();
        initUI_952();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(520, 300);
        setLocationRelativeTo(null);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                closeDB_952();
            }
        });
    }

    private void initDB_952() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // make sure connector is on classpath
            conn_952 = DriverManager.getConnection(DB_URL_952, DB_USER_952, DB_PASS_952);
            // create table if not exists
            String createSQL_952 = "CREATE TABLE IF NOT EXISTS electricity_bill (" +
                    "id INT PRIMARY KEY, " +
                    "name VARCHAR(100) NOT NULL, " +
                    "units INT NOT NULL, " +
                    "amount DOUBLE NOT NULL" +
                    ")";
            try (Statement st = conn_952.createStatement()) {
                st.execute(createSQL_952);
            }
        } catch (ClassNotFoundException e) {
            showErrorAndExit_952("MySQL JDBC driver not found. Add mysql-connector-java.jar to project libraries.");
        } catch (SQLException e) {
            showErrorAndExit_952("Database error: " + e.getMessage());
        }
    }

    private void initUI_952() {
        JPanel main_952 = new JPanel(new BorderLayout(10,10));

        // ---- Input form: ID, Name, Units + Calculate & Save
        JPanel form_952 = new JPanel(new GridLayout(3,2,6,6));
        form_952.setBorder(BorderFactory.createTitledBorder("Add / Calculate Bill"));

        idField_952 = new JTextField();
        nameField_952 = new JTextField();
        unitsField_952 = new JTextField();

        form_952.add(new JLabel("Customer ID (integer):"));
        form_952.add(idField_952);
        form_952.add(new JLabel("Customer Name:"));
        form_952.add(nameField_952);
        form_952.add(new JLabel("Units consumed (integer):"));
        form_952.add(unitsField_952);

        JPanel btnPanel_952 = new JPanel();
        calcSaveBtn_952 = new JButton("Calculate & Save");
        clearBtn_952 = new JButton("Clear");
        btnPanel_952.add(calcSaveBtn_952);
        btnPanel_952.add(clearBtn_952);

        calcSaveBtn_952.addActionListener(e -> calculateAndSave_952());
        clearBtn_952.addActionListener(e -> clearInputs_952());

        JPanel top_952 = new JPanel(new BorderLayout());
        top_952.add(form_952, BorderLayout.CENTER);
        top_952.add(btnPanel_952, BorderLayout.SOUTH);

        // ---- Search panel
        JPanel search_952 = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        search_952.setBorder(BorderFactory.createTitledBorder("Search by Customer Name"));
        search_952.add(new JLabel("Name:"));
        searchNameField_952 = new JTextField(18);
        search_952.add(searchNameField_952);
        searchBtn_952 = new JButton("Search");
        search_952.add(searchBtn_952);
        searchBtn_952.addActionListener(e -> searchBillByName_952());

        main_952.add(top_952, BorderLayout.CENTER);
        main_952.add(search_952, BorderLayout.SOUTH);

        setContentPane(main_952);
    }

    /**
     * Compute bill according to rules:
     *  - First 100 units -> ₹5/unit
     *  - Next 100 units (101 - 200) -> ₹7/unit
     *  - Above 200 -> ₹10/unit
     */
    private double computeBillAmount_952(int units_952) {
        double amount = 0.0;
        if (units_952 <= 0) return 0.0;
        int remaining = units_952;

        // first 100
        int first = Math.min(remaining, 100);
        amount += first * 5.0;
        remaining -= first;

        // next 100
        if (remaining > 0) {
            int second = Math.min(remaining, 100);
            amount += second * 7.0;
            remaining -= second;
        }

        // above 200
        if (remaining > 0) {
            amount += remaining * 10.0;
        }

        return amount;
    }

    private void calculateAndSave_952() {
        String idText = idField_952.getText().trim();
        String name = nameField_952.getText().trim();
        String unitsText = unitsField_952.getText().trim();

        if (idText.isEmpty() || name.isEmpty() || unitsText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter ID, Name and Units.", "Input required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int idVal;
        int unitsVal;
        try {
            idVal = Integer.parseInt(idText);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID must be an integer.", "Invalid input", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            unitsVal = Integer.parseInt(unitsText);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Units must be an integer.", "Invalid input", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (unitsVal < 0) {
            JOptionPane.showMessageDialog(this, "Units cannot be negative.", "Invalid input", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double amount = computeBillAmount_952(unitsVal);

        // Insert into DB using PreparedStatement
        String insertSQL = "INSERT INTO electricity_bill (id, name, units, amount) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pst = conn_952.prepareStatement(insertSQL)) {
            pst.setInt(1, idVal);
            pst.setString(2, name);
            pst.setInt(3, unitsVal);
            pst.setDouble(4, amount);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this,
                    String.format("Saved successfully!\nCustomer ID: %d\nName: %s\nUnits: %d\nAmount: ₹%.2f",
                            idVal, name, unitsVal, amount),
                    "Saved", JOptionPane.INFORMATION_MESSAGE);
            clearInputs_952();
        } catch (SQLException ex) {
            String msg = ex.getMessage() == null ? ex.toString() : ex.getMessage();
            if (msg.toLowerCase().contains("duplicate") || msg.toLowerCase().contains("constraint")) {
                JOptionPane.showMessageDialog(this, "A record with this ID already exists. Use a different ID.", "Duplicate ID", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Database error: " + msg, "DB Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void searchBillByName_952() {
        String name = searchNameField_952.getText().trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a name to search.", "Input required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String query = "SELECT id, name, units, amount FROM electricity_bill WHERE LOWER(name) = LOWER(?)";
        try (PreparedStatement pst = conn_952.prepareStatement(query)) {
            pst.setString(1, name);
            try (ResultSet rs = pst.executeQuery()) {
                StringBuilder sb = new StringBuilder();
                boolean found = false;
                while (rs.next()) {
                    found = true;
                    sb.append("Customer ID: ").append(rs.getInt("id")).append("\n");
                    sb.append("Name       : ").append(rs.getString("name")).append("\n");
                    sb.append("Units      : ").append(rs.getInt("units")).append("\n");
                    sb.append(String.format("Amount     : ₹%.2f\n", rs.getDouble("amount")));
                    sb.append("-------------------------------\n");
                }
                if (found) {
                    JTextArea ta = new JTextArea(sb.toString());
                    ta.setEditable(false);
                    ta.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
                    JScrollPane sp = new JScrollPane(ta);
                    sp.setPreferredSize(new Dimension(420, 180));
                    JOptionPane.showMessageDialog(this, sp, "Search results for '" + name + "'", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "No record found for: " + name, "Not found", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearInputs_952() {
        idField_952.setText("");
        nameField_952.setText("");
        unitsField_952.setText("");
    }

    private void closeDB_952() {
        if (conn_952 != null) {
            try {
                conn_952.close();
            } catch (SQLException ignored) {}
        }
    }

    private void showErrorAndExit_952(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Fatal Error", JOptionPane.ERROR_MESSAGE);
        System.exit(1);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ElectricityBillApp_952().setVisible(true);
        });
    }
}/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LEERA DEEP
 */
public class ElectricityBillApp_952 {
    
}
